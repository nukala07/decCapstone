package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.modal.Category;
import com.example.demo.repo.CategoryRepo;


@CrossOrigin(origins ="null", allowedHeaders = "*")
@RestController
@RequestMapping("/hp")
public class CategoryController {

	
	@Autowired
	private CategoryRepo CategoryRepo;
	
	 @PostMapping("/Category")
	    public Category createCategory(@RequestBody Category Category) {
	        return CategoryRepo.save(Category);
	    }
}
