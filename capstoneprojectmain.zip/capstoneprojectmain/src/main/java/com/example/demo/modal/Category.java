package com.example.demo.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Category")
public class Category {
	
	
	@Column(name ="Category_name")
	private String Category_name;
    @Id
	@Column(name ="Category_id")
	private int Category_id;

	
	

	public Category(String name, String email, String Category_name, int Category_id) {
		super();
		this.Category_name = Category_name;
		this.Category_id = Category_id;
		
	}

	public String getCategory_name() {
		return Category_name;
	}

	public void setCategory_name(int name, String Category_name) {
		this.Category_name = Category_name;
	}

	public int getCategory_id() {
		return Category_id;
	}
	

}
