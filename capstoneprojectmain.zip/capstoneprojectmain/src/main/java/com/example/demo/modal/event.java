package com.example.demo.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="event")
public class event {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int event_id;

	@Column(name ="event_name")
	private String event_name;

	@Column(name ="event_desc")
	private String event_desc;

	



	

	public event(int event_id, String event_name, String event_desc) {
		super();
		this.event_id = event_id;
		this.event_name = event_name;
		this.event_desc = event_desc;
		
	}


	public int event_id() {
		return event_id;
	}

	

	public String getevent_name() {
		return event_name;
	}

	public void setevent_name(String event_name) {
		this.event_name = event_name;
	}

	public String getevent_desc() {
		return event_desc;
	}

	public void setevent_desc(String event_desc) {
		this.event_desc = event_desc;
	
	}
	
	

}
